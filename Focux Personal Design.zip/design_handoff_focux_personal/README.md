# Handoff: Focux Personal — Design Completo

## Overview

Focux Personal é um SaaS mobile (Flutter) para personal trainers independentes gerenciarem alunos, treinos, financeiro e negócio numa única plataforma. Este pacote contém **31 telas de alta fidelidade** em dois temas (Daylight/Midnight) com o sistema de design completo.

## Sobre os Arquivos de Design

Os arquivos neste bundle são **protótipos de design em HTML** — mockups de alta fidelidade mostrando look, feel e comportamento pretendidos, **não código de produção para copiar diretamente**.

A tarefa é **recriar estes designs no Flutter** (o codebase existente em `devmatheus1912/focux-app`), usando as bibliotecas, providers e padrões já estabelecidos: Riverpod, GoRouter, Material 3, Design Tokens em `lib/core/theme/design_tokens.dart`.

O `AppTheme.dart` incluso já mapeia todos os tokens para Flutter — use-o como fonte primária para cores, tipografia e componentes.

## Fidelidade

**Alta fidelidade (hifi)**: Os mockups são pixel-perfect com cores finais, tipografia, espaçamentos e interações. O desenvolvedor deve recriar a UI com máxima fidelidade usando as bibliotecas Flutter existentes.

---

## Design Tokens

### Cores (copiar para `design_tokens.dart` / `AppTheme.dart`)

```dart
// Brand
brand:        #3B5FE2   // Electric Royal — cor primária
brandInk:     #2440B8   // Texto sobre fundo claro
brandSoft:    #EAF0FE   // Tint de fundo
brandSofter:  #F4F7FE   // Tint mais suave
brandDeep:    #0D1B5C   // Hero backgrounds
brandAccent:  #7CC0FF   // Highlight / dark mode primary

// Neutros (light)
paper:        #FAFAF8   // Scaffold background
card:         #FFFFFF   // Card surface
ink:          #0B1220   // Primary text
inkSoft:      #3A455C   // Secondary text
inkMute:      #6B7689   // Tertiary / placeholder
line:         #E6E6E0   // Dividers / borders
lineSoft:     #F0EFEA   // Subtle bg

// Neutros (dark)
darkBg:       #0A0F1E
darkCard:     #121A30
darkCardHi:   #1A2442
darkLine:     #1F2B4A
darkInk:      #F3F4F8
darkInkMute:  #8A94AE

// Semânticas
good:         #2B6A3F   goodSoft: #E4F1E9
warn:         #8A5A12   warnSoft: #FBEED6
bad:          #9E2B2B   badSoft:  #F7E3E3
```

### Tipografia

| Token | Família | Peso | Uso |
|---|---|---|---|
| Display | Space Grotesk | 600–700 | Números hero, títulos grandes |
| Text | Inter | 400–700 | Corpo, labels, UI |
| Mono | JetBrains Mono | 400–600 | Timers, códigos, dados tabulares |

### Border Radius Scale

```
xs: 8px   sm: 12px   md: 16px   lg: 20px   xl: 24px   2xl: 28px   pill: 999px
```

### Spacing Scale
`4 · 8 · 12 · 16 · 20 · 24 · 32px`

### Sombras

```
card-light:  inset 0 0 0 1px #E6E6E0
card-dark:   none (borda via border)
hero:        0 20px 40px -20px rgba(59,95,226,0.4)
dock:        0 10px 32px rgba(15,30,74,0.14), inset 0 0 0 0.5px rgba(0,0,0,0.04)
btn-primary: 0 6px 16px rgba(59,95,226,0.4)
```

---

## Arquitetura Visual

### Padrão de Layout (todas as telas)

```
SafeArea top (54px) ← status bar
─────────────────────────────────
Header (título + ações)
─────────────────────────────────
Content (ScrollView / ListView)
─────────────────────────────────
FxDock (bottom nav flutuante)   ← position: absolute, bottom: 18px
```

### Bottom Dock (Navegação Principal)

Dock flutuante com glassmorphism (blur 24px), 5 itens:

| Índice | Label | Rota |
|---|---|---|
| 0 | Hoje | /dashboard/personal |
| 1 | Alunos | /alunos |
| 2 | Treinos | /treinos |
| 3 | Finance | /financeiro |
| 4 | IA | /ia/copiloto |

**Estilo ativo**: ícone colorido (`brand`) + texto bold  
**Estilo inativo**: ícone e texto em `inkMute`  
**Container**: `borderRadius: 28, blur: 24, background: rgba(255,255,255,0.78)`

### Hero Cards (padrão recorrente)

Usado em Dashboard, Aluno Detail, Treino, Financeiro, Check-in, Auth:
```
background: LinearGradient(135°, brand → brandDeep)
borderRadius: 24–28px
boxShadow: 0 20px 40px -20px rgba(43,74,158,0.4)
padding: 22px
overlay: grid SVG opacity 0.06
```

---

## Telas — 31 no total

### 00 · Fluxo de Autenticação

#### Splash
- Fundo: radial gradient azul profundo (`#162D6B → #060C1E`)
- Logo FxMark tamanho 110px centralizado
- Wordmark "FOCUX" 42px Space Grotesk 700 + "PERSONAL" 15px tracking 0.28em
- Tagline italic 13px `rgba(255,255,255,0.4)`
- Loading dots (3) na base, primeiro dot mais largo (24px)

#### Intro Slides (3 slides)
- Fundo: mesmo gradiente azul profundo
- Dot navigation: dots ativos = 28px wide pill branco, inativos = 7px círculo `rgba(255,255,255,0.3)`
- Ícone em container 120×120px, `border-radius: 36px`, glass com glow colorido
- CTA primary: `height: 54, borderRadius: 14, gradient brand`
- Slides: Dumbbell (#7CC0FF) · Spark (#A0CCFF) · Coin (#B8D9FF)

#### Login
- Card glassmorphism: `background: rgba(255,255,255,0.05)`, `backdropFilter: blur(20px)`, `borderRadius: 28`
- Inputs: `background: rgba(255,255,255,0.07)`, `border: 1px solid rgba(255,255,255,0.14)`, `borderRadius: 14`
- Botão Google: `background: rgba(255,255,255,0.08)` (ghost)
- Divider com "ou continue com" em `rgba(255,255,255,0.4)`

#### Esqueci Senha
- Ícone "send" em container 72×72px, `borderRadius: 22`
- Campo de email + CTA enviar link
- Link "Voltar ao login" em `brandAccent`

#### Cadastro
- Mini lockup (mark 40px + wordmark)
- 4 campos: nome, email, senha, WhatsApp
- Seletor de plano 3 colunas: FREE / PREMIUM (highlight gradient) / ENTERPRISE
- Preços: FREE grátis · PREMIUM R$79/mês · ENTERPRISE R$149/mês
- 5 dias grátis nos planos pagos

---

### 01 · Dashboard do Personal

**Animações**:
- Hero gradient: ângulo rotaciona 0.4°/frame em loop (32ms interval)  
- Revenue counter: anima 0 → 8.420 em ~1.2s ao carregar

**Hero card**:
```
R$ 8.420 (Space Grotesk 44px 600) / R$ 11.750 prev.
Progress bar: width: 71%, height: 6px, bg: rgba(255,255,255,0.15)
3 stats inline: Pendente R$3.330 · Inadimpl. 2 · Ticket R$349
```

**Quick tiles 2×2**:  
Alunos ativos (24) · Check-ins hoje (9) · Risco alto (2) · Aderência (78%)  
Cada tile: `borderRadius: 18`, metric em `28px Space Grotesk 600`

**Seção "Precisa de atenção"**: scroll horizontal, cards 240px de largura  
**Seção "Aderência da semana"**: lista com sparklines 56×22px  
**Atalhos**: grid 3 colunas, cards 92px mínimo

---

### 02 · Lista de Alunos

- Header: "24 ativos · 2 inadimpl." 12px + "Alunos" 32px Space Grotesk
- FAB direita: círculo 44px brand com `+`
- Search bar com ícone filter à direita (brand color)
- Chips: Todos / Ativos / Inadimplentes / Risco alto / Novos
- Cards: avatar 48px + nome + obj + aderência com dot colorido + sparkline sem fill

**Cor da aderência**:
- ≥70%: `good` (#2B6A3F)
- ≥40%: `warn` (#8A5A12)  
- <40%: `bad` (#9E2B2B)

---

### 03 · Detalhe do Aluno

**Hero**: gradient brand 160px height  
- Avatar 72px branco (iniciais em brand color)  
- Nome 26px + objetivo 13px  
- Strip 4 stats: Aderência · Streak · PRs/mês · Total treinos

**Gráfico de peso**: sparkline 320×72px brand color com fill  
**Medidas**: grid 4 colunas (cintura/quadril/braço/coxa)  
**Módulos**: grid 2 colunas, "IA Progressão" em destaque (brandSoft bg)

---

### 04 · Financeiro

**Ring chart SVG**:
```
cx=60 cy=60 r=48, strokeWidth=10
stroke: brand, dasharray calculado de recebido/previsto
texto: "RECEBIDO" 11px + porcentagem 21px
```

**Bar chart 6 meses**: colunas flex com altura proporcional, barra atual em gradient brand  
**Vencimentos**: cards com avatar + nome + dias atraso + botão "Cobrar" inline  
**Top alunos**: lista com ranking numerado

---

### 05 · Detalhe do Treino

**Capa estilo playlist**: gradient 160° + cover tile 108×108px com ícone dumbbell  
**Ação primária**: botão branco 48px "Iniciar treino" (texto brand) — dominante  
**Exercícios**: agrupados por músculo com divider label  
Cada item: número em brandSoft circle + nome + séries×reps + carga + descanso + ícone more

---

### 06 · Check-in ao Vivo + IA

**Timer**: 56px Space Grotesk 600, `fontVariantNumeric: tabular-nums`  
**Badge AO VIVO**: pulsa opacidade 1→0.3 em 1.2s loop  
**Series grid**: cada linha tem status (✓ verde / ■ azul / ○ tracejado)  
**Card IA**: gradient brand com mini bar chart de RPE (5 barras)  
**Rest timer flutuante**: `bottom: 100px`, blur bg, ring SVG de progresso circular

---

### 07 · Chat

- Bolhas: `borderRadius: 18px 18px 4px 18px` (minha) / `18px 18px 18px 4px` (outra)
- Minha: gradient brand; outra: card branco
- Double check leitura: SVG duplo, azul quando lido
- Typing indicator: 3 dots com opacidade crescente
- Input: pill shape + ícone spark (IA) à direita + send button circular brand

---

### 08 · Copiloto IA

**Modo selector**: 3 colunas (Treino/Dieta/Progressão), ativo com bg brand  
**Context chips**: brandSofter bg, borda `rgba(59,95,226,0.15)`  
**Progress states**: 3 etapas com ✓ verde "Geração concluída"  
**Result card**: hero gradient + lista de exercícios com progressão colorida (good)  
**Nota IA**: brandSofter bg com borda brand-alpha

---

### 09 · Onboarding (Convite)

**Stepper**: 5 steps, feitos = brand filled, atual = brand borda, pendentes = lineSoft  
**Hero card**: gradient brand 32px padding, ícone de "conexão" (M + B sobrepostos)  
**Share buttons**: 3 colunas — WhatsApp (#25D366) · Email (brand) · Copiar (mute)

---

### 10 · Perfil do Personal

**Hero**: gradient 160° brand, cobre ~280px  
**Avatar**: 88×88px branco, iniciais brand 32px, badge editar 26px  
**Plano badge**: `🌟 PLANO PRO` dourado (#FFD37A), glass `rgba(255,255,255,0.15)`  
**Stats strip**: 4 colunas semitransparentes com dividers — Alunos/Treinos/Meses/Avaliação  
**Swatches de cor**: 5 círculos 36px `borderRadius: 12`

---

### 11 · Planos & Paywall

**Selector tabs**: 3 botões (FREE/PREMIUM/ENTERPRISE)  
- Ativo: `bg: brand color do plano, boxShadow: cor+44`  
- Inativo: glass com borda line

**Plan card hero**:
- PREMIUM: gradient `brand → brandDeep`
- ENTERPRISE: gradient `#C49A2A → #3A2600` (dourado)
- FREE: card neutro

**Trial badge**: `rgba(255,255,255,0.15)`, ícone clock + "X dias grátis"  
**Features list**: ✓ verde (goodSoft bg) / ✗ cinza (lineSoft bg), 52px height cada

**CTAs**:
- PREMIUM: `gradient brand, boxShadow: rgba(59,95,226,0.4)`
- ENTERPRISE: `gradient #C49A2A, boxShadow: rgba(196,154,42,0.4)`

---

### 12 · Landing Page Pública (White-label)

Fundo fixo: `#0A0F1E` (sempre dark, independente do tema do app)  
**Hero**: radial gradient azul + avatar 90px + glow `brandAccent`  
**Stats**: 3 colunas com dividers `rgba(255,255,255,0.15)`  
**Depoimentos**: cards `rgba(255,255,255,0.06)` + estrelas #FFD37A  
**CTA final**: gradient brand/navy, botão branco com texto brand  
**Footer**: "Criado com Focux Personal" + FxMark 20px

---

### 13 · Link na Bio Config

**Feature gate**: badge "ENTERPRISE" em brand  
**Link card**: borda `1.5px solid brand-alpha`, stats grid 3×1  
**Link row**: `FxMono 12px brand` + botão "Copiar" brandSoft  
**Config rows**: ícone em brandSoft circle + label + value + chevron

---

### 14 · Migração Mágica IA

**Hero card**: gradient brand, 3 steps numerados  
**Text paste area**: `FxMono 12px`, bg brandSofter, borda brand-alpha  
**Result cards**: avatar + nome/email/objetivo + ✓ verde  
**CTA confirmar**: goodSoft bg, borda good, texto good — `1.5px solid`

---

### 15 · Alertas de Risco

**Config strip**: brandSofter bg, texto "Sem treino > 7 dias · Aderência < 60%"  
**Summary chips**: 3 cards — Score alto (bad) / Score médio (warn) / Saudáveis (good)  
**Alert cards**: borda `bad-alpha` para score≥2  
**Action row**: 2 botões na base do card — "💬 Mensagem" (brand) / "✓ Resolvido" (good)

---

### 16 · Funil de Leads (CRM Kanban)

**Colunas**: LEAD (brand) / TESTE (warn) / ATIVO (good)  
Scroll horizontal, largura fixa 240px por coluna  
**Cards**: borda esquerda 3px colorida + ações WhatsApp + chevron  
**Add card**: dashed border, altura 40px

---

### 17 · Agenda Semanal

**Day tabs**: grid horizontal, dia atual = brand bg + shadow  
Tabs mostram contador de eventos em mini círculo brand  
**Event cards**: horário em FxMono brand + avatar + status colorido  
**Status cores**: AGENDADO (brand) / PRESENTE (good) / FALTA (bad) / CANCELADO (mute)

---

### 18 · Gamificação

**Streak hero**: `🔥 12 dias` em 44px Space Grotesk, gradient brand  
**Badge grid**: 3 colunas, ícone 48px em circle colorida, bloqueados opacity 0.45  
**Referral card**: código `FxMono 16px tracking 0.12em` + botão Copiar brand

---

### 19 · Analytics (ENTERPRISE)

**KPI grid 2×2**: MRR / Churn / LTV / CAC  
Cada: label uppercase mute + valor 26px Space Grotesk + delta com seta colorida  
**Bar chart**: flex height proporcional, barra atual = gradient brand, outras = brandSoft  
**Churn sparkline**: cor good (caindo = positivo)  
**Top LTV**: ranking numerado em brandSoft circle

---

### 20 · Anamnese

**3 tabs**: Básico / Saúde / Treino & Nutrição  
**TabBar**: indicador 2.5px brand, label brand quando ativo  
**Campos texto**: bg card, borderRadius 14, borda line, padding 13px  
**Slider**: track height 5px, thumb 16px branco com borda brand  
**Select**: row com value + chevronDown

---

### 21 · Feed de Conteúdo

**Tipo badges**: DICA (warn) / TEXTO (brand) / IMAGEM (good) / ENQUETE (roxo #6B46C1)  
**Post fixado**: borda 2px brand  
**Image placeholder**: gradient brand-alpha, altura 130px  
**Enquete**: opções como cards com borda line, altura 36px  
**Footer**: curtidas + comentários + data à direita

---

### 22 · Biblioteca de Exercícios

**GIF placeholder**: brandSoft 52×52 circle + dumbbell icon + badge vídeo 14px brand circle  
**Nível**: Iniciante=good / Intermediário=warn / Avançado=bad  
**Favorito**: ★ dourado (#FFD37A) quando ativo, ☆ mute quando inativo

---

### 23 · Relatório de Aderência

**Period selector**: pills com `borderRadius: 999`  
**Ring chart**:
```
svg: 140×140, cx=70 cy=70 r=54
stroke: good(≥75%) / warn(≥50%) / bad(<50%)
strokeWidth: 14, strokeLinecap: round
label central: taxa% + Excelente/Regular/Baixa
```
**Comparativo**: current (brand) ← delta badge → anterior (mute)  
Delta: `↑/↓ X.X%` em cor da tendência

---

### 24 · Evolução

**2 tabs**: Medidas Corporais / Recordes Pessoais  
**Banner variação**: `bg: good-18 ou bad-18`, ícone 📉/📈  
**Sparkline de peso**: 320×72, good color, fill=true  
**Medidas grid**: 4 chips por avaliação (peso/cintura/quadril/braço)  
**Recordes**: 🏆 em `#FFD37A22` bg + badge "NOVO PR" brand

---

### 25 · Ranking

**Pódio**: 3 colunas de altura variável [80/110/60px]  
Ordem visual: [Prata, Ouro, Bronze]  
Colunas: bg gradient brand (ouro) / brandSoft (demais)  
**Prêmio info**: `#FFF9E8 bg`, borda `#FFE58A`

---

### 26 · Broadcasts

**Composer**: card bg + campos + selector de público 4 botões  
**Histórico**: cards com badge "X alunos" em brandSoft + metadados

---

### 27 · Avaliação Física

**Summary 2×2**: peso/gordura/IMC/massa + deltas coloridos  
**Histórico**: grid 4 medidas por avaliação, badge "ATUAL" para mais recente

---

### 28 · Plano Alimentar

**Macro bar**: `height: 8, borderRadius: 8`  
```
proteína (red) · carboidrato (warn) · gordura (yellow)
flex proporcional às calorias de cada macro
```
**Refeições**: horário em FxMono brand (52px width) + itens expandíveis com dots

---

### 29 · Plano de Sucesso

**Ring SVG**: 80×80, r=32, `strokeDasharray` calculado  
**Etapas**: ✓ circle goodSoft / número circle atual brandSoft / número circle pending lineSoft  
Etapa atual: `border: 2px solid brand`

---

### 30 · Suporte

**Header**: avatar Focux (FxMark 32px em bg brand) + "online" em good  
**Quick actions**: chips brandSofter, borda brand-alpha  
**Mensagens**: mesmo padrão do Chat (tela 07)

---

### 31 · Notificações

**Grupos**: "HOJE" / "ONTEM" em uppercase mute label  
**Tipo → cor**:
- `risco` → bad  
- `pag` → good  
- `checkin` → brand  
- `ai` → #6B46C1  
- `aluno` → brand  
- `feed` → warn  

**Badge não lida**: dot 9px cor do tipo, `border: 2px solid cardBg`  
**Lidas**: `opacity: 0.75`

---

## Interações & Comportamentos

### Animações
- **Dashboard hero gradient**: rotate angle 0.4°/frame, 32ms interval, CSS `background` transition
- **Revenue counter**: RAF ou `setInterval 25ms`, step incremental de 0→8420
- **Badge AO VIVO**: `@keyframes pulse`, opacity 1→0.3, duration 1.2s, ease-in-out infinite
- **Intro slides dots**: width transition 7px→28px, `transition: all 300ms ease`

### Navegação
- Dock bottom: tab navigation com GoRouter
- Back button: `safePopOrGo(context, rota)` 
- Modal sheets: `showModalBottomSheet` com `isScrollControlled: true`

### Estados
- **Loading**: `CircularProgressIndicator(color: brand)`
- **Empty**: ícone centralizado + texto + CTA opcional
- **Error**: snackbar `bg: bad` com mensagem

### Scroll
- Listas: `padding bottom: 110px` (clearance do dock)
- ScrollView: sem scrollbars visíveis (`scrollbarWidth: none`)

---

## Assets

| Asset | Localização | Uso |
|---|---|---|
| Logo F (FOCUX PERSONAL) | `uploads/LOGOFOCUXPERSONAL_FULL.png` | Marca do produto, 3584×1024px |
| Logo mark crop | `brand/focux-mark.png` | App icon / headers, 788×1024px |

### Logo: implementação iOS
```dart
// mix-blend-mode não existe no Flutter — use:
// 1. Stack com o mark sobre bg escuro
// 2. ou use o asset PNG com fundo transparente (solicitar ao designer)
// Por enquanto, o mark pode ser recriado como SVG
```

---

## Arquivos do Bundle

| Arquivo | Descrição |
|---|---|
| `Focux Personal Design.html` | Canvas principal com todas as 31 telas × 2 skins |
| `src/tokens.jsx` | Sistema de design: cores, tipografia, componentes base (FxMark, FxDock, FxIcon, etc.) |
| `src/data.jsx` | Dados de demonstração realistas (BR) |
| `src/screen-dashboard.jsx` | Tela 01 |
| `src/screen-alunos.jsx` | Tela 02 |
| `src/screen-aluno-detail.jsx` | Tela 03 |
| `src/screen-financeiro.jsx` | Tela 04 |
| `src/screen-treino.jsx` | Tela 05 |
| `src/screen-checkin.jsx` | Tela 06 |
| `src/screen-chat.jsx` | Tela 07 |
| `src/screen-ia.jsx` | Tela 08 |
| `src/screen-onboarding.jsx` | Tela 09 |
| `src/screen-perfil.jsx` | Tela 10 |
| `src/screen-business.jsx` | Telas 11–14 (Paywall, Landing, Link na Bio, Migração) |
| `src/screen-operations.jsx` | Telas 15–19 (Alertas, Leads, Agenda, Gamificação, Analytics) |
| `src/screen-health.jsx` | Telas 20–25 (Anamnese, Feed, Exercícios, Relatório, Evolução, Ranking) |
| `src/screen-final.jsx` | Telas 26–31 (Broadcasts, Avaliação, Plano Alimentar, Sucesso, Suporte, Notificações) |
| `src/screen-auth.jsx` | Telas Auth (Splash, Intro, Login, Esqueci, Cadastro) |
| `AppTheme.dart` | Tokens Flutter prontos para usar |

---

## Como usar este handoff no Claude Code

```
Olá! Tenho um pacote de design handoff para o app Flutter Focux Personal.
O repositório Flutter está em: devmatheus1912/focux-app

O pacote inclui:
- 31 telas de alta fidelidade em HTML (referência visual)
- README.md com todos os tokens, specs e comportamentos
- AppTheme.dart pronto com as cores e tipografia

Por favor:
1. Abra o Focux Personal Design.html para ver os mockups
2. Use o README.md como guia de implementação
3. Copie o AppTheme.dart para lib/core/theme/
4. Implemente tela por tela seguindo as specs

Comece pela tela mais prioritária: [indique qual]
```

---

*Gerado em 01/05/2026 · Focux Personal v3 · 31 telas × 2 skins*
