// Telas: Anamnese, Feed de Conteúdo, Biblioteca Exercícios, Relatório Aderência, Evolução, Ranking

// ─────────────────────────────────────────────────────
// ANAMNESE — 3 tabs: Básico / Saúde / Treino & Nutrição
// ─────────────────────────────────────────────────────
function FxAnamnese({ dark = false }) {
  const bg = dark ? FX.darkBg : FX.paper;
  const cardBg = dark ? FX.darkCard : FX.card;
  const ink = dark ? FX.darkInk : FX.ink;
  const mute = dark ? FX.darkInkMute : FX.inkMute;
  const line = dark ? FX.darkLine : FX.line;
  const brand = dark ? FX.brandAccent : FX.brand;
  const [tab, setTab] = React.useState(0);

  const tabs = ['Básico', 'Saúde', 'Treino & Nutrição'];

  const fields = {
    0: [
      { label:'Objetivo principal', value:'Hipertrofia e definição muscular', lines:2 },
      { label:'Nível de atividade', value:'Moderado', type:'select', opts:['Sedentário','Leve','Moderado','Intenso','Muito Intenso'] },
      { label:'Lesões / Limitações', value:'Dor no ombro esquerdo (antigo)', lines:2 },
      { label:'Medicamentos em uso', value:'Nenhum', lines:1 },
      { label:'Observações gerais', value:'Prefere treinos pela manhã', lines:2 },
    ],
    1: [
      { label:'Histórico médico', value:'Nenhuma condição relevante', lines:3 },
      { label:'Cirurgias realizadas', value:'Nenhuma', lines:2 },
      { label:'Dores crônicas', value:'Leve dor lombar eventual', lines:2 },
    ],
    2: [
      { label:'Objetivo detalhado', value:'Ganhar 3–4kg de massa magra em 6 meses mantendo gordura controlada', lines:3 },
      { label:'Disponibilidade semanal', value:'3 dias/semana', type:'slider', val:3, max:7 },
      { label:'Preferências de treino', value:'Push/Pull/Legs, exercícios compostos', lines:2 },
      { label:'Restrições alimentares', value:'Intolerante à lactose', lines:1 },
    ],
  };

  return (
    <div style={{ background: bg, minHeight: '100%', display: 'flex', flexDirection: 'column', paddingBottom: 90 }}>
      <div style={{ height: 54 }} />

      {/* Header */}
      <div style={{ background: cardBg, borderBottom: `1px solid ${line}` }}>
        <div style={{ padding: '10px 20px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ ...FxText, fontSize: 11, color: mute, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Beatriz Carvalho</div>
            <div style={{ ...FxDisplay, fontSize: 22, fontWeight: 700, color: ink, letterSpacing: '-0.02em' }}>Anamnese</div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <div style={{ padding: '8px 12px', borderRadius: 10, background: dark ? 'rgba(255,255,255,0.06)' : FX.lineSoft,
              border: `1px solid ${line}`, ...FxText, fontSize: 12, fontWeight: 600, color: mute,
              display: 'flex', alignItems: 'center', gap: 5 }}>
              <FxIcon name="send" size={12} color={mute} stroke={2}/> PDF
            </div>
            <div style={{ padding: '8px 12px', borderRadius: 10, background: brand,
              ...FxText, fontSize: 12, fontWeight: 700, color: '#fff' }}>Salvar</div>
          </div>
        </div>
        {/* Tab bar */}
        <div style={{ display: 'flex', padding: '10px 16px 0' }}>
          {tabs.map((t, i) => (
            <div key={t} onClick={() => setTab(i)} style={{ flex: 1, textAlign: 'center',
              padding: '10px 4px 12px', cursor: 'pointer',
              borderBottom: i === tab ? `2.5px solid ${brand}` : '2.5px solid transparent',
              ...FxText, fontSize: 13, fontWeight: i === tab ? 700 : 500,
              color: i === tab ? brand : mute,
            }}>{t}</div>
          ))}
        </div>
      </div>

      {/* Fields */}
      <div style={{ flex: 1, padding: '20px 16px', display: 'flex', flexDirection: 'column', gap: 14, overflowY: 'auto' }}>
        {(fields[tab] || []).map((f, i) => (
          <div key={i}>
            <div style={{ ...FxText, fontSize: 12, fontWeight: 600, color: mute, marginBottom: 6, letterSpacing: '0.03em' }}>{f.label}</div>
            {f.type === 'slider' ? (
              <div style={{ background: cardBg, borderRadius: 14, padding: '14px 16px', border: `1px solid ${line}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                  <div style={{ ...FxDisplay, fontSize: 28, fontWeight: 700, color: ink }}>{f.val}</div>
                  <div style={{ ...FxText, fontSize: 12, color: mute }}>dias/semana</div>
                </div>
                <div style={{ height: 5, borderRadius: 5, background: line, position: 'relative' }}>
                  <div style={{ width: `${(f.val / f.max) * 100}%`, height: '100%', borderRadius: 5, background: brand }}/>
                  <div style={{ position: 'absolute', left: `${(f.val / f.max) * 100}%`, top: '50%',
                    transform: 'translate(-50%,-50%)', width: 16, height: 16, borderRadius: 16,
                    background: '#fff', border: `2px solid ${brand}`, boxShadow: '0 2px 6px rgba(0,0,0,0.12)',
                  }}/>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6,
                  ...FxText, fontSize: 10, color: mute }}>
                  <span>1</span><span>{f.max}</span>
                </div>
              </div>
            ) : f.type === 'select' ? (
              <div style={{ background: cardBg, borderRadius: 14, padding: '13px 16px', border: `1px solid ${line}`,
                display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ ...FxText, fontSize: 15, color: ink }}>{f.value}</div>
                <FxIcon name="chevDown" size={16} color={mute} stroke={2}/>
              </div>
            ) : (
              <div style={{ background: cardBg, borderRadius: 14, padding: '13px 16px', border: `1px solid ${line}`,
                minHeight: f.lines > 1 ? 60 : 48 }}>
                <div style={{ ...FxText, fontSize: 15, color: f.value ? ink : mute, lineHeight: 1.5 }}>
                  {f.value || 'Toque para preencher…'}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────
// FEED DE CONTEÚDO — personal publica para alunos
// ─────────────────────────────────────────────────────
function FxFeed({ dark = false }) {
  const bg = dark ? FX.darkBg : FX.paper;
  const cardBg = dark ? FX.darkCard : FX.card;
  const ink = dark ? FX.darkInk : FX.ink;
  const mute = dark ? FX.darkInkMute : FX.inkMute;
  const line = dark ? FX.darkLine : FX.line;
  const brand = dark ? FX.brandAccent : FX.brand;

  const posts = [
    { id:1, tipo:'DICA', titulo:'Dica de hoje: pausa entre séries', conteudo:'Para hipertrofia o descanso ideal é 60–90s entre séries. Mais que isso reduz o volume total do treino.', fixado:true, curtidas:14, comentarios:3, data:'2026-04-25' },
    { id:2, tipo:'TEXTO', titulo:'Lembrete: semana de deload', conteudo:'Galera, essa semana é de deload! Reduz 40% da carga em todos os exercícios. Seu corpo vai agradecer na próxima semana 💪', fixado:false, curtidas:22, comentarios:7, data:'2026-04-23' },
    { id:3, tipo:'IMAGEM', titulo:'Comparativo 3 meses', conteudo:'Veja a evolução incrível da Beatriz em 3 meses de treino consistente. Isso é o que acontece quando você não falta!', fixado:false, curtidas:38, comentarios:12, data:'2026-04-20', hasImage:true },
    { id:4, tipo:'ENQUETE', titulo:'Próximo conteúdo: qual preferem?', conteudo:'Vote no próximo tema que vou abordar no feed:','opcoes':['Técnica de execução dos compostos','Periodização para iniciantes','Suplementação básica'], fixado:false, curtidas:8, comentarios:2, data:'2026-04-18' },
  ];

  const tipoMeta = {
    DICA:   { icon: 'spark',    label: 'Dica', color: dark ? '#E2B46F' : FX.warn },
    TEXTO:  { icon: 'chat',     label: 'Texto', color: brand },
    IMAGEM: { icon: 'calendar', label: 'Imagem', color: dark ? '#6FE296' : FX.good },
    VIDEO:  { icon: 'play',     label: 'Vídeo', color: brand },
    ENQUETE:{ icon: 'filter',   label: 'Enquete', color: dark ? '#9B7AFF' : '#6B46C1' },
  };

  return (
    <div style={{ background: bg, minHeight: '100%', paddingBottom: 110 }}>
      <div style={{ height: 54 }} />
      <div style={{ padding: '10px 20px 18px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div style={{ ...FxDisplay, fontSize: 28, fontWeight: 700, color: ink, letterSpacing: '-0.025em' }}>Feed</div>
        <div style={{ width: 44, height: 44, borderRadius: 44, background: brand,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: `0 6px 16px rgba(59,95,226,0.4)` }}>
          <FxIcon name="plus" size={20} color="#fff" stroke={2.2}/>
        </div>
      </div>

      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {posts.map(p => {
          const meta = tipoMeta[p.tipo] || tipoMeta.TEXTO;
          return (
            <div key={p.id} style={{ background: cardBg, borderRadius: 22, overflow: 'hidden',
              border: p.fixado ? `2px solid ${brand}` : `1px solid ${line}`,
            }}>
              {/* header */}
              <div style={{ padding: '14px 16px 10px', display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                {p.fixado && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, position: 'absolute',
                    ...FxText, fontSize: 10, color: brand, fontWeight: 700 }}>
                    📌
                  </div>
                )}
                <div style={{ width: 32, height: 32, borderRadius: 10, flexShrink: 0,
                  background: `${meta.color}20`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <FxIcon name={meta.icon} size={15} color={meta.color} stroke={1.8}/>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
                    {p.fixado && <div style={{ ...FxText, fontSize: 10, color: brand, fontWeight: 700 }}>📌 Fixado</div>}
                    <div style={{ padding: '2px 7px', borderRadius: 6, background: `${meta.color}18`,
                      ...FxText, fontSize: 10, fontWeight: 700, color: meta.color }}>
                      {meta.label.toUpperCase()}
                    </div>
                  </div>
                  <div style={{ ...FxDisplay, fontSize: 15, fontWeight: 600, color: ink, letterSpacing: '-0.01em' }}>{p.titulo}</div>
                </div>
                <FxIcon name="more" size={16} color={mute} stroke={2}/>
              </div>

              {/* body */}
              <div style={{ padding: '0 16px 12px' }}>
                <div style={{ ...FxText, fontSize: 14, color: ink, lineHeight: 1.55 }}>{p.conteudo}</div>
                {p.opcoes && (
                  <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {p.opcoes.map((o, i) => (
                      <div key={i} style={{ padding: '9px 14px', borderRadius: 10, border: `1.5px solid ${line}`,
                        ...FxText, fontSize: 13, color: ink }}>
                        {o}
                      </div>
                    ))}
                  </div>
                )}
                {p.hasImage && (
                  <div style={{ marginTop: 10, height: 130, borderRadius: 14, overflow: 'hidden',
                    background: `linear-gradient(135deg, ${FX.brand}33, ${FX.brandDeep}55)`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <div style={{ ...FxText, fontSize: 12, color: mute }}>📸 Foto antes × depois</div>
                  </div>
                )}
              </div>

              {/* footer */}
              <div style={{ borderTop: `1px solid ${line}`, padding: '10px 16px',
                display: 'flex', alignItems: 'center', gap: 16 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 4, ...FxText, fontSize: 12, color: mute }}>
                  <FxIcon name="trend" size={13} color={mute} stroke={2}/> {p.curtidas}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 4, ...FxText, fontSize: 12, color: mute }}>
                  <FxIcon name="chat" size={13} color={mute} stroke={2}/> {p.comentarios}
                </div>
                <div style={{ flex: 1, ...FxText, fontSize: 11, color: mute, textAlign: 'right' }}>
                  {p.data.substring(5).replace('-','/')}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────
// BIBLIOTECA DE EXERCÍCIOS
// ─────────────────────────────────────────────────────
function FxExercicios({ dark = false }) {
  const bg = dark ? FX.darkBg : FX.paper;
  const cardBg = dark ? FX.darkCard : FX.card;
  const ink = dark ? FX.darkInk : FX.ink;
  const mute = dark ? FX.darkInkMute : FX.inkMute;
  const line = dark ? FX.darkLine : FX.line;
  const brand = dark ? FX.brandAccent : FX.brand;
  const [catAtiva, setCat] = React.useState('Todos');

  const cats = ['Todos','Musculação','Funcional','Cardio','Mobilidade'];

  const exercicios = [
    { n:'Supino reto com barra',    grupo:'Peito',   nivel:'Intermediário', mecanica:'Composto',  video:true,  fav:true  },
    { n:'Agachamento livre',         grupo:'Pernas',  nivel:'Intermediário', mecanica:'Composto',  video:true,  fav:true  },
    { n:'Puxada frontal',            grupo:'Costas',  nivel:'Iniciante',     mecanica:'Composto',  video:true,  fav:false },
    { n:'Desenvolvimento halter',    grupo:'Ombro',   nivel:'Iniciante',     mecanica:'Composto',  video:false, fav:false },
    { n:'Rosca direta',              grupo:'Bíceps',  nivel:'Iniciante',     mecanica:'Isolado',   video:true,  fav:true  },
    { n:'Tríceps pulley corda',      grupo:'Tríceps', nivel:'Iniciante',     mecanica:'Isolado',   video:false, fav:false },
    { n:'Elevação lateral',          grupo:'Ombro',   nivel:'Iniciante',     mecanica:'Isolado',   video:true,  fav:false },
  ];

  const nivelColor = { 'Iniciante': dark ? '#6FE296' : FX.good, 'Intermediário': dark ? '#E2B46F' : FX.warn, 'Avançado': dark ? '#FF8B8B' : FX.bad };

  return (
    <div style={{ background: bg, minHeight: '100%', paddingBottom: 110 }}>
      <div style={{ height: 54 }} />
      <div style={{ padding: '10px 20px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <div style={{ ...FxText, fontSize: 11, color: mute, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 2 }}>CATÁLOGO</div>
          <div style={{ ...FxDisplay, fontSize: 28, fontWeight: 700, color: ink, letterSpacing: '-0.025em' }}>Exercícios</div>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: cardBg, border: `1px solid ${line}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <FxIcon name="filter" size={16} color={mute} stroke={2}/>
          </div>
          <div style={{ width: 44, height: 44, borderRadius: 14, background: brand,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: `0 6px 16px rgba(59,95,226,0.4)` }}>
            <FxIcon name="plus" size={20} color="#fff" stroke={2.2}/>
          </div>
        </div>
      </div>

      {/* Search */}
      <div style={{ padding: '0 16px 10px' }}>
        <div style={{ background: cardBg, borderRadius: 14, padding: '12px 14px', border: `1px solid ${line}`,
          display: 'flex', alignItems: 'center', gap: 10 }}>
          <FxIcon name="search" size={16} color={mute} stroke={2}/>
          <div style={{ ...FxText, fontSize: 14, color: mute }}>Buscar por nome ou grupo…</div>
        </div>
      </div>

      {/* Category chips */}
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', padding: '0 16px 14px', scrollbarWidth: 'none' }}>
        {cats.map(c => (
          <button key={c} onClick={() => setCat(c)} style={{
            padding: '8px 14px', borderRadius: 999, border: 'none', cursor: 'pointer', whiteSpace: 'nowrap',
            background: c === catAtiva ? (dark ? '#fff' : FX.ink) : (dark ? 'rgba(255,255,255,0.06)' : '#fff'),
            color: c === catAtiva ? (dark ? FX.ink : '#fff') : (dark ? FX.darkInk : FX.ink),
            ...FxText, fontSize: 12.5, fontWeight: 600,
            boxShadow: c === catAtiva ? 'none' : `inset 0 0 0 1px ${line}`,
            flexShrink: 0,
          }}>{c}</button>
        ))}
      </div>

      {/* List */}
      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {exercicios.map((ex, i) => (
          <div key={i} style={{ background: cardBg, borderRadius: 18, padding: '13px 14px', border: `1px solid ${line}`,
            display: 'flex', alignItems: 'center', gap: 12 }}>
            {/* GIF placeholder */}
            <div style={{ width: 52, height: 52, borderRadius: 12, flexShrink: 0,
              background: dark ? 'rgba(141,164,226,0.12)' : FX.brandSoft,
              display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
              <FxIcon name="dumbbell" size={22} color={brand} stroke={1.5}/>
              {ex.video && (
                <div style={{ position: 'absolute', bottom: 2, right: 2, width: 14, height: 14, borderRadius: 14,
                  background: brand, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <FxIcon name="play" size={8} color="#fff"/>
                </div>
              )}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ ...FxText, fontSize: 14, fontWeight: 600, color: ink, letterSpacing: '-0.01em' }}>{ex.n}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 3 }}>
                <div style={{ ...FxText, fontSize: 11, color: mute }}>{ex.grupo}</div>
                <div style={{ width: 3, height: 3, borderRadius: 3, background: mute, opacity: 0.5 }}/>
                <div style={{ ...FxText, fontSize: 11, color: nivelColor[ex.nivel] || mute, fontWeight: 600 }}>{ex.nivel}</div>
                <div style={{ width: 3, height: 3, borderRadius: 3, background: mute, opacity: 0.5 }}/>
                <div style={{ ...FxText, fontSize: 11, color: mute }}>{ex.mecanica}</div>
              </div>
            </div>
            <div style={{ color: ex.fav ? '#FFD37A' : mute, fontSize: 16 }}>{ex.fav ? '★' : '☆'}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────
// RELATÓRIO DE ADERÊNCIA
// ─────────────────────────────────────────────────────
function FxRelatorio({ dark = false }) {
  const bg = dark ? FX.darkBg : FX.paper;
  const cardBg = dark ? FX.darkCard : FX.card;
  const ink = dark ? FX.darkInk : FX.ink;
  const mute = dark ? FX.darkInkMute : FX.inkMute;
  const line = dark ? FX.darkLine : FX.line;
  const brand = dark ? FX.brandAccent : FX.brand;
  const [periodo, setPeriodo] = React.useState(30);

  const dados = { taxa: 92, treinosConcluidos: 18, treinosTotal: 20, diasAnalisados: 30,
    comparativo: { atual: 92, anterior: 78, checkInsAtual: 18, checkInsAnterior: 14 } };

  const cor = dados.taxa >= 75 ? (dark ? '#6FE296' : FX.good) : dados.taxa >= 50 ? (dark ? '#E2B46F' : FX.warn) : (dark ? '#FF8B8B' : FX.bad);
  const label = dados.taxa >= 75 ? 'Excelente' : dados.taxa >= 50 ? 'Regular' : 'Baixa';
  const delta = dados.comparativo.atual - dados.comparativo.anterior;

  const circumference = 2 * Math.PI * 54;
  const dashArray = `${(dados.taxa / 100) * circumference} ${circumference}`;

  return (
    <div style={{ background: bg, minHeight: '100%', paddingBottom: 110 }}>
      <div style={{ height: 54 }} />
      <div style={{ padding: '10px 20px 18px', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
        <div>
          <div style={{ ...FxText, fontSize: 11, color: mute, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>Beatriz Carvalho</div>
          <div style={{ ...FxDisplay, fontSize: 26, fontWeight: 700, color: ink, letterSpacing: '-0.025em' }}>Relatório</div>
        </div>
        <div style={{ padding: '8px 12px', borderRadius: 10, background: dark ? 'rgba(255,255,255,0.06)' : FX.lineSoft,
          border: `1px solid ${line}`, ...FxText, fontSize: 12, fontWeight: 600, color: mute,
          display: 'flex', alignItems: 'center', gap: 5 }}>
          <FxIcon name="send" size={12} color={mute} stroke={2}/> Exportar PDF
        </div>
      </div>

      {/* Period selector */}
      <div style={{ padding: '0 16px 16px', display: 'flex', gap: 8 }}>
        {[30, 60, 90].map(d => (
          <button key={d} onClick={() => setPeriodo(d)} style={{
            padding: '8px 16px', borderRadius: 999, border: 'none', cursor: 'pointer',
            background: periodo === d ? brand : (dark ? 'rgba(255,255,255,0.06)' : '#fff'),
            color: periodo === d ? '#fff' : ink,
            ...FxText, fontSize: 13, fontWeight: 600,
            boxShadow: periodo === d ? `0 4px 12px rgba(59,95,226,0.35)` : `inset 0 0 0 1px ${line}`,
          }}>{d}d</button>
        ))}
        <button style={{ padding: '8px 16px', borderRadius: 999, border: 'none', cursor: 'pointer',
          background: dark ? 'rgba(255,255,255,0.06)' : '#fff', color: mute,
          ...FxText, fontSize: 13, fontWeight: 600, boxShadow: `inset 0 0 0 1px ${line}`,
        }}>Custom</button>
      </div>

      {/* Ring chart */}
      <div style={{ padding: '0 16px 16px' }}>
        <div style={{ background: cardBg, borderRadius: 24, padding: '24px',
          border: `1px solid ${line}`, display: 'flex', flexDirection: 'column', alignItems: 'center',
        }}>
          <div style={{ ...FxText, fontSize: 13, fontWeight: 600, color: mute, marginBottom: 20 }}>Taxa de Aderência · {periodo} dias</div>
          <div style={{ position: 'relative', width: 140, height: 140 }}>
            <svg width="140" height="140" viewBox="0 0 140 140" style={{ transform: 'rotate(-90deg)' }}>
              <circle cx="70" cy="70" r="54" fill="none" stroke={dark ? 'rgba(255,255,255,0.08)' : FX.brandSoft} strokeWidth="14"/>
              <circle cx="70" cy="70" r="54" fill="none" stroke={cor} strokeWidth="14"
                strokeLinecap="round" strokeDasharray={dashArray}/>
            </svg>
            <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center' }}>
              <div style={{ ...FxDisplay, fontSize: 30, fontWeight: 700, color: cor, letterSpacing: '-0.02em' }}>
                {dados.taxa}%
              </div>
              <div style={{ ...FxText, fontSize: 12, color: cor, fontWeight: 600 }}>{label}</div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 24, marginTop: 20 }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ ...FxDisplay, fontSize: 22, fontWeight: 700, color: ink }}>{dados.treinosConcluidos}</div>
              <div style={{ ...FxText, fontSize: 11, color: mute }}>de {dados.treinosTotal} treinos</div>
            </div>
            <div style={{ width: 1, background: line }}/>
            <div style={{ textAlign: 'center' }}>
              <div style={{ ...FxDisplay, fontSize: 22, fontWeight: 700, color: ink }}>{dados.diasAnalisados}d</div>
              <div style={{ ...FxText, fontSize: 11, color: mute }}>período</div>
            </div>
          </div>
        </div>
      </div>

      {/* Comparativo */}
      <div style={{ padding: '0 16px 16px' }}>
        <div style={{ background: cardBg, borderRadius: 22, padding: '18px', border: `1px solid ${line}` }}>
          <div style={{ ...FxText, fontSize: 12, fontWeight: 600, color: mute, marginBottom: 14,
            textTransform: 'uppercase', letterSpacing: '0.06em' }}>vs. período anterior</div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ ...FxText, fontSize: 11, color: mute, marginBottom: 4 }}>Este período</div>
              <div style={{ ...FxDisplay, fontSize: 26, fontWeight: 700, color: brand }}>{dados.comparativo.atual}%</div>
              <div style={{ ...FxText, fontSize: 11, color: mute }}>{dados.comparativo.checkInsAtual} check-ins</div>
            </div>
            <div style={{ padding: '8px 14px', borderRadius: 12, background: `${cor}18`,
              display: 'flex', alignItems: 'center', gap: 4,
              ...FxText, fontSize: 14, fontWeight: 700, color: cor }}>
              {delta >= 0 ? '↑' : '↓'} {Math.abs(delta).toFixed(1)}%
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ ...FxText, fontSize: 11, color: mute, marginBottom: 4 }}>Anterior</div>
              <div style={{ ...FxDisplay, fontSize: 26, fontWeight: 700, color: mute }}>{dados.comparativo.anterior}%</div>
              <div style={{ ...FxText, fontSize: 11, color: mute }}>{dados.comparativo.checkInsAnterior} check-ins</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────
// EVOLUÇÃO — medidas corporais + recordes pessoais
// ─────────────────────────────────────────────────────
function FxEvolucao({ dark = false }) {
  const bg = dark ? FX.darkBg : FX.paper;
  const cardBg = dark ? FX.darkCard : FX.card;
  const ink = dark ? FX.darkInk : FX.ink;
  const mute = dark ? FX.darkInkMute : FX.inkMute;
  const line = dark ? FX.darkLine : FX.line;
  const brand = dark ? FX.brandAccent : FX.brand;
  const [tab, setTab] = React.useState(0);

  const medidas = [
    { data:'25/04/2026', peso:64.3, cintura:68, quadril:94, braco:28 },
    { data:'11/04/2026', peso:64.8, cintura:69, quadril:95, braco:27.5 },
    { data:'28/03/2026', peso:65.4, cintura:70, quadril:95, braco:27 },
    { data:'14/03/2026', peso:66.1, cintura:71, quadril:96, braco:26.5 },
    { data:'28/02/2026', peso:66.9, cintura:72, quadril:97, braco:26 },
  ];

  const recordes = [
    { exercicio:'Supino reto com barra', carga:100, reps:4,  data:'25/04/2026', isNew:true },
    { exercicio:'Agachamento livre',     carga:85,  reps:5,  data:'18/04/2026', isNew:false },
    { exercicio:'Puxada frontal',        carga:60,  reps:10, data:'11/04/2026', isNew:false },
    { exercicio:'Desenvolvimento halter',carga:18,  reps:10, data:'04/04/2026', isNew:false },
  ];

  const diff = medidas[0].peso - medidas[medidas.length - 1].peso;

  return (
    <div style={{ background: bg, minHeight: '100%', paddingBottom: 110 }}>
      <div style={{ height: 54 }} />

      {/* Header */}
      <div style={{ background: cardBg, borderBottom: `1px solid ${line}` }}>
        <div style={{ padding: '10px 20px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ ...FxText, fontSize: 11, color: mute, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Beatriz Carvalho</div>
            <div style={{ ...FxDisplay, fontSize: 22, fontWeight: 700, color: ink, letterSpacing: '-0.02em' }}>Evolução</div>
          </div>
          <div style={{ width: 44, height: 44, borderRadius: 14, background: brand,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: `0 6px 16px rgba(59,95,226,0.4)` }}>
            <FxIcon name="plus" size={20} color="#fff" stroke={2.2}/>
          </div>
        </div>
        <div style={{ display: 'flex', padding: '10px 16px 0' }}>
          {['Medidas Corporais','Recordes Pessoais'].map((t, i) => (
            <div key={t} onClick={() => setTab(i)} style={{ flex: 1, textAlign: 'center',
              padding: '10px 4px 12px', cursor: 'pointer',
              borderBottom: i === tab ? `2.5px solid ${brand}` : '2.5px solid transparent',
              ...FxText, fontSize: 13, fontWeight: i === tab ? 700 : 500,
              color: i === tab ? brand : mute,
            }}>{t}</div>
          ))}
        </div>
      </div>

      {/* Banner variação */}
      {tab === 0 && (
        <div style={{ background: diff < 0 ? `${FX.good}18` : `${FX.bad}18`,
          padding: '10px 20px', display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 16 }}>{diff < 0 ? '📉' : '📈'}</span>
          <div style={{ ...FxText, fontSize: 13, fontWeight: 600,
            color: diff < 0 ? (dark ? '#6FE296' : FX.good) : (dark ? '#FF8B8B' : FX.bad) }}>
            {diff > 0 ? '+' : ''}{diff.toFixed(1)}kg desde o início
          </div>
        </div>
      )}

      {/* Content */}
      {tab === 0 ? (
        <div style={{ padding: '16px 16px 0', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {/* sparkline card */}
          <div style={{ background: cardBg, borderRadius: 22, padding: '16px', border: `1px solid ${line}` }}>
            <div style={{ ...FxText, fontSize: 11.5, color: mute, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>Peso · últimas semanas</div>
            <FxSparkline data={medidas.map(m => m.peso).reverse()} w={320} h={72} color={dark ? '#6FE296' : FX.good} fill />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6 }}>
              <div style={{ ...FxText, fontSize: 11, color: mute }}>{medidas[medidas.length-1].peso}kg</div>
              <div style={{ ...FxDisplay, fontSize: 16, fontWeight: 700, color: ink }}>{medidas[0].peso}kg</div>
            </div>
          </div>

          {medidas.map((m, i) => (
            <div key={i} style={{ background: cardBg, borderRadius: 18, padding: '14px 16px', border: `1px solid ${line}` }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <FxIcon name="calendar" size={13} color={mute} stroke={2}/>
                  <div style={{ ...FxText, fontSize: 12, color: mute }}>{m.data}</div>
                </div>
                {i === 0 && <div style={{ ...FxText, fontSize: 10, fontWeight: 700, color: brand,
                  background: dark ? 'rgba(141,164,226,0.14)' : FX.brandSoft, padding: '2px 8px', borderRadius: 999 }}>MAIS RECENTE</div>}
              </div>
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                {[['Peso', m.peso, 'kg'], ['Cintura', m.cintura, 'cm'], ['Quadril', m.quadril, 'cm'], ['Braço', m.braco, 'cm']].map(([l, v, u]) => (
                  <div key={l} style={{ padding: '8px 12px', borderRadius: 10,
                    background: dark ? 'rgba(255,255,255,0.04)' : FX.paper, border: `1px solid ${line}` }}>
                    <div style={{ ...FxText, fontSize: 10, color: mute }}>{l}</div>
                    <div style={{ ...FxDisplay, fontSize: 16, fontWeight: 700, color: ink }}>{v}<span style={{ fontSize: 10, color: mute, fontWeight: 400 }}>{u}</span></div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ padding: '16px 16px 0', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {recordes.map((r, i) => (
            <div key={i} style={{ background: cardBg, borderRadius: 18, padding: '14px 16px', border: `1px solid ${line}`,
              display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 44, height: 44, borderRadius: 14, background: `#FFD37A22`,
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>🏆</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ ...FxText, fontSize: 14, fontWeight: 600, color: ink }}>{r.exercicio}</div>
                <div style={{ ...FxText, fontSize: 11.5, color: mute, marginTop: 1 }}>{r.data}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ ...FxDisplay, fontSize: 18, fontWeight: 700, color: ink }}>{r.carga}kg</div>
                <div style={{ ...FxText, fontSize: 11, color: mute }}>{r.reps} reps</div>
                {r.isNew && <div style={{ ...FxText, fontSize: 9.5, fontWeight: 700, color: brand, textTransform: 'uppercase', letterSpacing: '0.06em' }}>NOVO PR</div>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────
// RANKING DE PERSONAIS
// ─────────────────────────────────────────────────────
function FxRanking({ dark = false }) {
  const bg = dark ? FX.darkBg : FX.paper;
  const cardBg = dark ? FX.darkCard : FX.card;
  const ink = dark ? FX.darkInk : FX.ink;
  const mute = dark ? FX.darkInkMute : FX.inkMute;
  const line = dark ? FX.darkLine : FX.line;
  const brand = dark ? FX.brandAccent : FX.brand;

  const ranking = [
    { pos:1, nome:'Marcos Oliveira',  alunos:68, cidade:'SP', medalha:'🥇', desc:20 },
    { pos:2, nome:'Matheus Ribeiro',  alunos:47, cidade:'SP', medalha:'🥈', desc:15 },
    { pos:3, nome:'Carla Mendonça',   alunos:41, cidade:'RJ', medalha:'🥉', desc:10 },
    { pos:4, nome:'Diego Fernandes',  alunos:38, cidade:'BH', medalha:null,  desc:null },
    { pos:5, nome:'Priscila Santos',  alunos:35, cidade:'SP', medalha:null,  desc:null },
    { pos:6, nome:'Rafael Correia',   alunos:29, cidade:'DF', medalha:null,  desc:null },
    { pos:7, nome:'Amanda Vieira',    alunos:24, cidade:'SP', medalha:null,  desc:null },
  ];

  const top3 = ranking.slice(0, 3);
  const demais = ranking.slice(3);

  const podioAltura = [80, 110, 60]; // prata, ouro, bronze
  const podioOrder = [1, 0, 2]; // prata primeiro, ouro centro, bronze direita

  return (
    <div style={{ background: bg, minHeight: '100%', paddingBottom: 110 }}>
      <div style={{ height: 54 }} />
      <div style={{ padding: '10px 20px 20px' }}>
        <div style={{ ...FxDisplay, fontSize: 28, fontWeight: 700, color: ink, letterSpacing: '-0.025em' }}>Ranking</div>
        <div style={{ ...FxText, fontSize: 13, color: mute, marginTop: 4 }}>Top personais por alunos ativos · maio 2026</div>
      </div>

      {/* Pódio */}
      <div style={{ padding: '0 16px 20px' }}>
        <div style={{ background: cardBg, borderRadius: 24, padding: '24px 16px 0', border: `1px solid ${line}`, overflow: 'hidden' }}>
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'center', gap: 8 }}>
            {podioOrder.map(idx => {
              const p = top3[idx];
              const h = podioAltura[idx];
              const isPrimeiro = p.pos === 1;
              return (
                <div key={p.pos} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <div style={{ fontSize: 28, marginBottom: 4 }}>{p.medalha}</div>
                  <FxAvatar name={p.nome} size={isPrimeiro ? 52 : 42} dark={dark} />
                  <div style={{ ...FxText, fontSize: 12, fontWeight: 600, color: ink, marginTop: 6, textAlign: 'center',
                    overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 90 }}>{p.nome.split(' ')[0]}</div>
                  <div style={{ ...FxText, fontSize: 11, color: brand, fontWeight: 600, marginBottom: 8 }}>{p.alunos} alunos</div>
                  {p.desc && (
                    <div style={{ ...FxText, fontSize: 10, fontWeight: 700, color: '#FFD37A', marginBottom: 6 }}>
                      {p.desc}% OFF
                    </div>
                  )}
                  <div style={{ width: '100%', height: h, borderRadius: '8px 8px 0 0',
                    background: isPrimeiro
                      ? (dark ? `linear-gradient(180deg, #8DA4E2, #3D5FBE)` : `linear-gradient(180deg, ${FX.brand}, ${FX.brandInk})`)
                      : (dark ? 'rgba(255,255,255,0.08)' : FX.brandSoft),
                  }}/>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Prêmio info */}
      <div style={{ padding: '0 16px 16px' }}>
        <div style={{ background: dark ? 'rgba(255,215,122,0.1)' : '#FFF9E8', borderRadius: 16, padding: '12px 16px',
          border: `1px solid ${dark ? 'rgba(255,215,122,0.2)' : '#FFE58A'}`,
          display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ fontSize: 20 }}>🎁</div>
          <div>
            <div style={{ ...FxText, fontSize: 13, fontWeight: 700, color: ink }}>Top 3 ganham desconto na assinatura!</div>
            <div style={{ ...FxText, fontSize: 12, color: mute, marginTop: 1 }}>1º 20% · 2º 15% · 3º 10% de desconto</div>
          </div>
        </div>
      </div>

      {/* Lista demais */}
      <div style={{ padding: '0 20px 12px', ...FxDisplay, fontSize: 18, fontWeight: 600, color: ink, letterSpacing: '-0.01em' }}>
        Classificação geral
      </div>
      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {demais.map(p => (
          <div key={p.pos} style={{ background: cardBg, borderRadius: 16, padding: '12px 14px',
            border: `1px solid ${line}`, display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 34, height: 34, borderRadius: 34,
              background: dark ? 'rgba(255,255,255,0.06)' : FX.lineSoft,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              ...FxDisplay, fontSize: 14, fontWeight: 700, color: mute }}>{p.pos}</div>
            <FxAvatar name={p.nome} size={36} dark={dark}/>
            <div style={{ flex: 1 }}>
              <div style={{ ...FxText, fontSize: 14, fontWeight: 600, color: ink }}>{p.nome}</div>
              <div style={{ ...FxText, fontSize: 11.5, color: mute }}>{p.alunos} alunos · {p.cidade}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, {
  FxAnamnese, FxFeed, FxExercicios, FxRelatorio, FxEvolucao, FxRanking,
});
