// Telas finais: Broadcasts, Avaliação Física, Plano Alimentar, Plano de Sucesso, Suporte, Notificações

// ─────────────────────────────────────────────────────
// BROADCASTS — mensageria em massa para alunos
// ─────────────────────────────────────────────────────
function FxBroadcasts({ dark = false }) {
  const bg = dark ? FX.darkBg : FX.paper;
  const cardBg = dark ? FX.darkCard : FX.card;
  const ink = dark ? FX.darkInk : FX.ink;
  const mute = dark ? FX.darkInkMute : FX.inkMute;
  const line = dark ? FX.darkLine : FX.line;
  const brand = dark ? FX.brandAccent : FX.brand;
  const [publico, setPublico] = React.useState('TODOS');

  const publicoOpts = ['TODOS','ONLINE','PRESENCIAL','HÍBRIDO'];
  const historico = [
    { titulo:'🔥 Semana de deload — cuide-se!', msg:'Essa semana reduz 40% da carga. Seu corpo precisa de recuperação.', alunos:24, publico:'TODOS', data:'25/04 · 09:12' },
    { titulo:'📅 Reagendamento — quinta-feira', msg:'O treino de quinta foi transferido para às 18h no mesmo local.', alunos:12, publico:'PRESENCIAL', data:'22/04 · 16:45' },
    { titulo:'✨ Novo recurso: IA de progressão', msg:'Agora você tem sugestões automáticas de carga toda semana no app!', alunos:24, publico:'TODOS', data:'18/04 · 10:00' },
  ];

  return (
    <div style={{ background: bg, minHeight: '100%', paddingBottom: 100 }}>
      <div style={{ height: 54 }} />
      <div style={{ padding: '10px 20px 18px' }}>
        <div style={{ ...FxText, fontSize: 11, color: brand, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 4 }}>Central de Mensageria</div>
        <div style={{ ...FxDisplay, fontSize: 26, fontWeight: 700, color: ink, letterSpacing: '-0.025em' }}>Broadcasts</div>
      </div>

      {/* Compose card */}
      <div style={{ padding: '0 16px 18px' }}>
        <div style={{ background: cardBg, borderRadius: 22, padding: '18px', border: `1px solid ${line}` }}>
          <div style={{ ...FxText, fontSize: 13, fontWeight: 700, color: ink, marginBottom: 14 }}>Nova mensagem</div>

          {/* Title field */}
          <div style={{ ...FxText, fontSize: 11.5, color: mute, fontWeight: 600, marginBottom: 5 }}>Título</div>
          <div style={{ background: dark ? 'rgba(255,255,255,0.05)' : FX.paper, borderRadius: 12, padding: '12px 14px',
            border: `1px solid ${line}`, marginBottom: 12 }}>
            <div style={{ ...FxText, fontSize: 14, color: mute }}>Ex.: Lembrete de treino…</div>
          </div>

          {/* Message field */}
          <div style={{ ...FxText, fontSize: 11.5, color: mute, fontWeight: 600, marginBottom: 5 }}>Mensagem</div>
          <div style={{ background: dark ? 'rgba(255,255,255,0.05)' : FX.paper, borderRadius: 12, padding: '12px 14px',
            border: `1px solid ${line}`, minHeight: 80, marginBottom: 14 }}>
            <div style={{ ...FxText, fontSize: 14, color: mute }}>Digite sua mensagem para os alunos…</div>
          </div>

          {/* Público-alvo */}
          <div style={{ ...FxText, fontSize: 11.5, color: mute, fontWeight: 600, marginBottom: 8 }}>Público-alvo</div>
          <div style={{ display: 'flex', gap: 7, marginBottom: 18 }}>
            {publicoOpts.map(p => (
              <button key={p} onClick={() => setPublico(p)} style={{
                flex: 1, padding: '8px 4px', borderRadius: 10, border: 'none', cursor: 'pointer',
                background: publico === p ? brand : (dark ? 'rgba(255,255,255,0.05)' : FX.paper),
                color: publico === p ? '#fff' : mute,
                ...FxText, fontSize: 10.5, fontWeight: 600,
                boxShadow: publico === p ? `0 4px 10px rgba(59,95,226,0.35)` : `inset 0 0 0 1px ${line}`,
              }}>{p}</button>
            ))}
          </div>

          <div style={{ height: 48, borderRadius: 12, background: brand,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            color: '#fff', ...FxText, fontSize: 14, fontWeight: 700,
            boxShadow: `0 6px 16px rgba(59,95,226,0.4)`,
          }}>
            <FxIcon name="send" size={16} color="#fff" stroke={2}/> Enviar notificação
          </div>
        </div>
      </div>

      {/* Histórico */}
      <div style={{ padding: '0 20px 12px', ...FxDisplay, fontSize: 18, fontWeight: 600, color: ink, letterSpacing: '-0.01em' }}>
        Histórico
      </div>
      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {historico.map((h, i) => (
          <div key={i} style={{ background: cardBg, borderRadius: 18, padding: '14px 16px', border: `1px solid ${line}` }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
              <div style={{ ...FxText, fontSize: 14, fontWeight: 600, color: ink, flex: 1, marginRight: 10 }}>{h.titulo}</div>
              <div style={{ padding: '3px 8px', borderRadius: 999,
                background: dark ? 'rgba(141,164,226,0.15)' : FX.brandSoft,
                ...FxText, fontSize: 11, fontWeight: 700, color: brand, flexShrink: 0,
              }}>{h.alunos} alunos</div>
            </div>
            <div style={{ ...FxText, fontSize: 13, color: mute, lineHeight: 1.4, marginBottom: 8 }}>{h.msg}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4, ...FxText, fontSize: 11, color: mute }}>
                <FxIcon name="users" size={12} color={mute} stroke={1.8}/> {h.publico}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4, ...FxText, fontSize: 11, color: mute }}>
                <FxIcon name="clock" size={12} color={mute} stroke={1.8}/> {h.data}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────
// AVALIAÇÃO FÍSICA — medidas + composição corporal
// ─────────────────────────────────────────────────────
function FxAvaliacaoFisica({ dark = false }) {
  const bg = dark ? FX.darkBg : FX.paper;
  const cardBg = dark ? FX.darkCard : FX.card;
  const ink = dark ? FX.darkInk : FX.ink;
  const mute = dark ? FX.darkInkMute : FX.inkMute;
  const line = dark ? FX.darkLine : FX.line;
  const brand = dark ? FX.brandAccent : FX.brand;

  const avaliacoes = [
    { data:'25/04/2026', peso:64.3, altura:168, imc:22.8, gordura:18.2, massa:52.6, cintura:68, quadril:94, braco:28, coxa:55, enviado:true  },
    { data:'11/04/2026', peso:64.8, altura:168, imc:23.0, gordura:19.1, massa:52.4, cintura:69, quadril:95, braco:27.5, coxa:54, enviado:true },
    { data:'28/03/2026', peso:65.4, altura:168, imc:23.2, gordura:20.0, massa:52.3, cintura:70, quadril:95, braco:27, coxa:54, enviado:false },
  ];

  const atual = avaliacoes[0];
  const anterior = avaliacoes[1];
  const diffPeso = atual.peso - anterior.peso;
  const diffGordura = atual.gordura - anterior.gordura;

  return (
    <div style={{ background: bg, minHeight: '100%', paddingBottom: 110 }}>
      <div style={{ height: 54 }} />
      <div style={{ padding: '10px 20px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <div style={{ ...FxText, fontSize: 11, color: mute, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>Beatriz Carvalho</div>
          <div style={{ ...FxDisplay, fontSize: 26, fontWeight: 700, color: ink, letterSpacing: '-0.025em' }}>Avaliação Física</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: cardBg, border: `1px solid ${line}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <FxIcon name="trend" size={16} color={brand} stroke={2}/>
          </div>
          <div style={{ width: 44, height: 44, borderRadius: 14, background: brand,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: `0 6px 16px rgba(59,95,226,0.4)` }}>
            <FxIcon name="plus" size={20} color="#fff" stroke={2.2}/>
          </div>
        </div>
      </div>

      {/* Summary cards */}
      <div style={{ padding: '0 16px 16px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {[
          { label:'Peso atual', value:`${atual.peso}kg`, delta: diffPeso.toFixed(1), up: diffPeso > 0 },
          { label:'% Gordura', value:`${atual.gordura}%`, delta: diffGordura.toFixed(1), up: diffGordura > 0 },
          { label:'IMC', value: atual.imc.toFixed(1), sub:'Saudável', noArrow:true },
          { label:'Massa magra', value:`${atual.massa}kg`, sub:'+0.2kg', noArrow:true },
        ].map((m, i) => (
          <div key={i} style={{ background: cardBg, borderRadius: 18, padding: '16px',
            border: `1px solid ${line}` }}>
            <div style={{ ...FxText, fontSize: 11.5, color: mute, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>{m.label}</div>
            <div style={{ ...FxDisplay, fontSize: 26, fontWeight: 700, color: ink, letterSpacing: '-0.02em', lineHeight: 1 }}>{m.value}</div>
            {m.delta !== undefined ? (
              <div style={{ display: 'flex', alignItems: 'center', gap: 3, marginTop: 6 }}>
                <div style={{ ...FxText, fontSize: 12, fontWeight: 600,
                  color: m.up ? (dark ? '#FF8B8B' : FX.bad) : (dark ? '#6FE296' : FX.good) }}>
                  {Number(m.delta) > 0 ? '+' : ''}{m.delta}kg vs anterior
                </div>
              </div>
            ) : (
              <div style={{ ...FxText, fontSize: 12, color: mute, marginTop: 6 }}>{m.sub}</div>
            )}
          </div>
        ))}
      </div>

      {/* Medidas list */}
      <div style={{ padding: '0 20px 12px', ...FxDisplay, fontSize: 18, fontWeight: 600, color: ink, letterSpacing: '-0.01em' }}>
        Histórico de avaliações
      </div>
      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {avaliacoes.map((a, i) => (
          <div key={i} style={{ background: cardBg, borderRadius: 20, padding: '16px', border: `1px solid ${line}` }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <div style={{ ...FxText, fontSize: 13, fontWeight: 600, color: ink }}>{a.data}</div>
              <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                {i === 0 && <div style={{ padding: '3px 8px', borderRadius: 999, background: dark ? 'rgba(141,164,226,0.15)' : FX.brandSoft,
                  ...FxText, fontSize: 10, fontWeight: 700, color: brand }}>ATUAL</div>}
                {a.enviado && <div style={{ ...FxText, fontSize: 10, color: dark ? '#6FE296' : FX.good, fontWeight: 600,
                  display: 'flex', alignItems: 'center', gap: 3 }}>
                  <FxIcon name="check" size={10} color="currentColor" stroke={2}/> Enviada
                </div>}
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
              {[['Peso', a.peso, 'kg'], ['Gordura', a.gordura, '%'], ['Cintura', a.cintura, 'cm'], ['Quadril', a.quadril, 'cm']].map(([l, v, u]) => (
                <div key={l} style={{ textAlign: 'center', padding: '8px 4px', borderRadius: 10,
                  background: dark ? 'rgba(255,255,255,0.04)' : FX.paper, border: `1px solid ${line}` }}>
                  <div style={{ ...FxText, fontSize: 9.5, color: mute, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{l}</div>
                  <div style={{ ...FxDisplay, fontSize: 16, fontWeight: 700, color: ink, marginTop: 2 }}>{v}<span style={{ fontSize: 9, color: mute, fontWeight: 400 }}>{u}</span></div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────
// PLANO ALIMENTAR — macros por refeição
// ─────────────────────────────────────────────────────
function FxPlanoAlimentar({ dark = false }) {
  const bg = dark ? FX.darkBg : FX.paper;
  const cardBg = dark ? FX.darkCard : FX.card;
  const ink = dark ? FX.darkInk : FX.ink;
  const mute = dark ? FX.darkInkMute : FX.inkMute;
  const line = dark ? FX.darkLine : FX.line;
  const brand = dark ? FX.brandAccent : FX.brand;

  const plano = {
    nome: 'Plano Hipertrofia · Beatriz',
    calorias: 2200,
    proteina: 176, carboidrato: 242, gordura: 61,
    refeicoes: [
      { horario:'07:00', nome:'Café da manhã', cal:480, itens:['3 ovos mexidos', 'Aveia 60g', 'Banana média', '200ml leite sem lactose'] },
      { horario:'10:00', nome:'Lanche da manhã', cal:220, itens:['Iogurte grego 200g', '30g granola', '1 maçã'] },
      { horario:'13:00', nome:'Almoço', cal:680, itens:['180g frango grelhado', '4 col. arroz integral', '150g batata doce', 'Salada à vontade', '1 col. azeite'] },
      { horario:'16:00', nome:'Pré-treino', cal:320, itens:['Banana + pasta de amendoim 30g', 'Whey 30g em água'] },
      { horario:'20:00', nome:'Jantar', cal:500, itens:['150g salmão assado', '150g batata doce', 'Brócolis refogado', '1 col. azeite'] },
    ],
  };

  const macroColor = { prot: dark ? '#FF8B8B' : FX.bad, carbo: dark ? '#E2B46F' : FX.warn, gord: '#FFD37A' };
  const totalCal = plano.proteina * 4 + plano.carboidrato * 4 + plano.gordura * 9;

  return (
    <div style={{ background: bg, minHeight: '100%', paddingBottom: 110 }}>
      <div style={{ height: 54 }} />
      <div style={{ padding: '10px 20px 18px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <div style={{ ...FxText, fontSize: 11, color: mute, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>Beatriz Carvalho</div>
          <div style={{ ...FxDisplay, fontSize: 24, fontWeight: 700, color: ink, letterSpacing: '-0.025em' }}>Plano Alimentar</div>
        </div>
        <div style={{ width: 44, height: 44, borderRadius: 14, background: brand,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: `0 6px 16px rgba(59,95,226,0.4)` }}>
          <FxIcon name="plus" size={20} color="#fff" stroke={2.2}/>
        </div>
      </div>

      {/* Macros hero */}
      <div style={{ padding: '0 16px 16px' }}>
        <div style={{ background: cardBg, borderRadius: 24, padding: '20px',
          border: `1px solid ${line}` }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 16 }}>
            <div style={{ ...FxDisplay, fontSize: 36, fontWeight: 700, color: ink, letterSpacing: '-0.03em' }}>{plano.calorias}</div>
            <div style={{ ...FxText, fontSize: 14, color: mute }}>kcal/dia</div>
          </div>
          {/* macro bar */}
          <div style={{ height: 8, borderRadius: 8, overflow: 'hidden', display: 'flex', marginBottom: 14 }}>
            <div style={{ flex: plano.proteina * 4, background: macroColor.prot }}/>
            <div style={{ flex: plano.carboidrato * 4, background: macroColor.carbo }}/>
            <div style={{ flex: plano.gordura * 9, background: macroColor.gord }}/>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
            {[
              { label:'Proteína', value: plano.proteina, unit:'g', color: macroColor.prot, pct: Math.round(plano.proteina*4/totalCal*100) },
              { label:'Carboidrato', value: plano.carboidrato, unit:'g', color: macroColor.carbo, pct: Math.round(plano.carboidrato*4/totalCal*100) },
              { label:'Gordura', value: plano.gordura, unit:'g', color: macroColor.gord, pct: Math.round(plano.gordura*9/totalCal*100) },
            ].map(m => (
              <div key={m.label} style={{ padding: '10px', borderRadius: 12, background: dark ? 'rgba(255,255,255,0.04)' : FX.paper,
                border: `1px solid ${line}`, textAlign: 'center' }}>
                <div style={{ width: 8, height: 8, borderRadius: 8, background: m.color, margin: '0 auto 6px' }}/>
                <div style={{ ...FxDisplay, fontSize: 18, fontWeight: 700, color: ink }}>{m.value}<span style={{ fontSize: 11, color: mute, fontWeight: 400 }}>{m.unit}</span></div>
                <div style={{ ...FxText, fontSize: 10.5, color: mute }}>{m.pct}% · {m.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Refeições */}
      <div style={{ padding: '0 20px 12px', ...FxDisplay, fontSize: 18, fontWeight: 600, color: ink, letterSpacing: '-0.01em' }}>
        Refeições
      </div>
      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {plano.refeicoes.map((r, i) => (
          <div key={i} style={{ background: cardBg, borderRadius: 18, overflow: 'hidden', border: `1px solid ${line}` }}>
            <div style={{ padding: '13px 14px', display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 52, textAlign: 'center', flexShrink: 0 }}>
                <div style={{ ...FxMono, fontSize: 14, fontWeight: 700, color: brand }}>{r.horario}</div>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ ...FxText, fontSize: 14, fontWeight: 600, color: ink }}>{r.nome}</div>
                <div style={{ ...FxText, fontSize: 12, color: mute, marginTop: 1 }}>{r.cal} kcal</div>
              </div>
              <FxIcon name="chevDown" size={15} color={mute} stroke={2}/>
            </div>
            <div style={{ padding: '0 14px 12px 80px', display: 'flex', flexDirection: 'column', gap: 3 }}>
              {r.itens.map((it, j) => (
                <div key={j} style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                  <div style={{ width: 4, height: 4, borderRadius: 4, background: mute, flexShrink: 0 }}/>
                  <div style={{ ...FxText, fontSize: 12.5, color: mute }}>{it}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────
// PLANO DE SUCESSO — onboarding estruturado do aluno
// ─────────────────────────────────────────────────────
function FxPlanoSucesso({ dark = false }) {
  const bg = dark ? FX.darkBg : FX.paper;
  const cardBg = dark ? FX.darkCard : FX.card;
  const ink = dark ? FX.darkInk : FX.ink;
  const mute = dark ? FX.darkInkMute : FX.inkMute;
  const line = dark ? FX.darkLine : FX.line;
  const brand = dark ? FX.brandAccent : FX.brand;

  const etapas = [
    { n:1, titulo:'Anamnese preenchida',         done:true,  desc:'Histórico de saúde e objetivos registrados.' },
    { n:2, titulo:'Avaliação física inicial',    done:true,  desc:'Peso, medidas e composição corporal.' },
    { n:3, titulo:'Treino atribuído',            done:true,  desc:'Push A/B/C atribuído e explicado.' },
    { n:4, titulo:'Plano alimentar enviado',     done:true,  desc:'2200 kcal · 176g proteína · plano hipertrofia.' },
    { n:5, titulo:'Primeiro check-in feito',     done:false, desc:'Aluna realizou o 1º treino no app.', current:true },
    { n:6, titulo:'Retorno 30 dias',             done:false, desc:'Revisão de evolução e ajuste de cargas.' },
    { n:7, titulo:'Avaliação de resultado final',done:false, desc:'Comparativo antes × depois + relatório PDF.' },
  ];

  const pct = Math.round(etapas.filter(e => e.done).length / etapas.length * 100);

  return (
    <div style={{ background: bg, minHeight: '100%', paddingBottom: 110 }}>
      <div style={{ height: 54 }} />
      <div style={{ padding: '10px 20px 18px' }}>
        <div style={{ ...FxText, fontSize: 11, color: mute, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>Beatriz Carvalho</div>
        <div style={{ ...FxDisplay, fontSize: 24, fontWeight: 700, color: ink, letterSpacing: '-0.025em' }}>Plano de Sucesso</div>
      </div>

      {/* Progress hero */}
      <div style={{ padding: '0 16px 18px' }}>
        <div style={{ borderRadius: 24, overflow: 'hidden', position: 'relative',
          background: dark ? `linear-gradient(135deg, #1A2852, #060D28)` : `linear-gradient(135deg, ${FX.brand}, ${FX.brandDeep})`,
          padding: '22px 22px',
        }}>
          <svg style={{ position: 'absolute', inset: 0, opacity: 0.06 }} width="100%" height="100%">
            <defs><pattern id="gg-ps" width="26" height="26" patternUnits="userSpaceOnUse">
              <path d="M 26 0 L 0 0 0 26" fill="none" stroke="#fff" strokeWidth="0.5"/></pattern></defs>
            <rect width="100%" height="100%" fill="url(#gg-ps)" />
          </svg>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, position: 'relative' }}>
            <div style={{ position: 'relative', width: 80, height: 80, flexShrink: 0 }}>
              <svg width="80" height="80" viewBox="0 0 80 80" style={{ transform: 'rotate(-90deg)' }}>
                <circle cx="40" cy="40" r="32" fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="8"/>
                <circle cx="40" cy="40" r="32" fill="none" stroke="#fff" strokeWidth="8" strokeLinecap="round"
                  strokeDasharray={`${(pct / 100) * 2 * Math.PI * 32} ${2 * Math.PI * 32}`}/>
              </svg>
              <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <div style={{ ...FxDisplay, fontSize: 18, fontWeight: 700, color: '#fff' }}>{pct}%</div>
              </div>
            </div>
            <div>
              <div style={{ ...FxText, fontSize: 10, color: 'rgba(255,255,255,0.65)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Progresso do onboarding</div>
              <div style={{ ...FxDisplay, fontSize: 22, fontWeight: 700, color: '#fff', marginTop: 4 }}>
                {etapas.filter(e => e.done).length} de {etapas.length} etapas
              </div>
              <div style={{ ...FxText, fontSize: 13, color: 'rgba(255,255,255,0.65)', marginTop: 4 }}>
                Próximo: Primeiro check-in
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Etapas */}
      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {etapas.map((e, i) => (
          <div key={i} style={{ background: cardBg, borderRadius: 18, padding: '14px 14px',
            border: e.current ? `2px solid ${brand}` : `1px solid ${line}`,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 36, height: 36, borderRadius: 36, flexShrink: 0,
                background: e.done
                  ? (dark ? 'rgba(111,226,150,0.15)' : FX.goodSoft)
                  : e.current
                  ? (dark ? 'rgba(141,164,226,0.15)' : FX.brandSoft)
                  : (dark ? 'rgba(255,255,255,0.04)' : FX.lineSoft),
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {e.done ? (
                  <svg width="14" height="11" viewBox="0 0 14 11" fill="none">
                    <path d="M1 5.5l4 4 8-8" stroke={dark ? '#6FE296' : FX.good} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                ) : (
                  <div style={{ ...FxMono, fontSize: 13, fontWeight: 700, color: e.current ? brand : mute }}>{e.n}</div>
                )}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ ...FxText, fontSize: 14, fontWeight: 600,
                  color: e.done ? (dark ? '#6FE296' : FX.good) : e.current ? brand : ink,
                }}>{e.titulo}</div>
                <div style={{ ...FxText, fontSize: 12, color: mute, marginTop: 2 }}>{e.desc}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────
// SUPORTE — chat com suporte Focux
// ─────────────────────────────────────────────────────
function FxSuporte({ dark = false }) {
  const bg = dark ? FX.darkBg : FX.paper;
  const cardBg = dark ? FX.darkCard : FX.card;
  const ink = dark ? FX.darkInk : FX.ink;
  const mute = dark ? FX.darkInkMute : FX.inkMute;
  const line = dark ? FX.darkLine : FX.line;
  const brand = dark ? FX.brandAccent : FX.brand;

  const msgs = [
    { from:'user', text:'Oi! Como faço para gerar um link de pagamento para um aluno específico?', time:'09:14' },
    { from:'focux', text:'Olá Matheus! Você pode fazer isso direto na tela Financeiro → selecione o aluno → gerar PIX/link. Quer que eu te mostre um passo a passo?', time:'09:15' },
    { from:'user', text:'Perfeito, consegui! Uma dúvida: tem como personalizar a cor da minha landing page?', time:'09:18' },
    { from:'focux', text:'Sim! Acesse Perfil → Identidade Visual → Cor da marca. A mudança reflete automaticamente na sua landing page em até 5 minutos 🎨', time:'09:19' },
    { from:'user', text:'Show, muito obrigado!', time:'09:20' },
  ];

  return (
    <div style={{ background: bg, minHeight: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <div style={{ paddingTop: 54, background: cardBg, boxShadow: dark ? 'none' : '0 1px 0 ' + line }}>
        <div style={{ padding: '10px 16px 14px', display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 34, height: 34, borderRadius: 34, background: dark ? 'rgba(255,255,255,0.06)' : FX.lineSoft,
            display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="9" height="15" viewBox="0 0 10 16" fill="none"><path d="M8 2L2 8l6 6" stroke={ink} strokeWidth="2.2" strokeLinecap="round"/></svg>
          </div>
          {/* Focux support avatar */}
          <div style={{ width: 42, height: 42, borderRadius: 42, overflow: 'hidden', flexShrink: 0,
            background: `linear-gradient(135deg, ${FX.brand}, ${FX.brandDeep})`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <FxMark size={32} variant="official" onDark />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ ...FxDisplay, fontSize: 16, fontWeight: 600, color: ink }}>Suporte Focux</div>
            <div style={{ ...FxText, fontSize: 12, color: dark ? '#6FE296' : FX.good, fontWeight: 500, marginTop: 1 }}>● online · resposta imediata</div>
          </div>
          <div style={{ padding: '6px 10px', borderRadius: 999,
            background: dark ? 'rgba(141,164,226,0.15)' : FX.brandSoft,
            ...FxText, fontSize: 11, fontWeight: 700, color: brand }}>
            Central de Ajuda
          </div>
        </div>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 14px', display: 'flex', flexDirection: 'column', gap: 8,
        scrollbarWidth: 'none', minHeight: 400 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '4px 0 10px' }}>
          <div style={{ flex: 1, height: 0.5, background: line }}/><div style={{ ...FxText, fontSize: 11, color: mute }}>hoje · 09:14</div>
          <div style={{ flex: 1, height: 0.5, background: line }}/>
        </div>

        {msgs.map((m, i) => {
          const isMe = m.from === 'user';
          return (
            <div key={i} style={{ display: 'flex', flexDirection: isMe ? 'row-reverse' : 'row', alignItems: 'flex-end', gap: 8 }}>
              {!isMe && (
                <div style={{ width: 28, height: 28, borderRadius: 28, background: `linear-gradient(135deg, ${FX.brand}, ${FX.brandDeep})`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <FxMark size={22} variant="official" onDark />
                </div>
              )}
              <div style={{ maxWidth: '74%' }}>
                <div style={{
                  padding: '10px 14px', borderRadius: isMe ? '18px 18px 4px 18px' : '18px 18px 18px 4px',
                  background: isMe
                    ? (dark ? `linear-gradient(135deg, #2440B8, #1A2F8A)` : `linear-gradient(135deg, ${FX.brand}, ${FX.brandInk})`)
                    : (dark ? FX.darkCardHi : '#fff'),
                  color: isMe ? '#fff' : ink,
                  border: !isMe ? `1px solid ${line}` : 'none',
                  boxShadow: !isMe ? '0 1px 2px rgba(0,0,0,0.05)' : 'none',
                }}>
                  <div style={{ ...FxText, fontSize: 14, lineHeight: 1.45 }}>{m.text}</div>
                </div>
                <div style={{ ...FxText, fontSize: 10.5, color: mute, marginTop: 4, textAlign: isMe ? 'right' : 'left', padding: '0 4px' }}>{m.time}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick actions */}
      <div style={{ padding: '10px 14px 8px', display: 'flex', gap: 8, overflowX: 'auto', scrollbarWidth: 'none' }}>
        {['Como gerar PIX?', 'Upgrade de plano', 'Migração de dados', 'Problema técnico'].map(q => (
          <div key={q} style={{ padding: '7px 12px', borderRadius: 999, flexShrink: 0,
            background: dark ? 'rgba(141,164,226,0.1)' : FX.brandSofter,
            border: `1px solid ${dark ? 'rgba(141,164,226,0.2)' : 'rgba(59,95,226,0.15)'}`,
            ...FxText, fontSize: 12, fontWeight: 500, color: brand, whiteSpace: 'nowrap',
          }}>{q}</div>
        ))}
      </div>

      {/* Input */}
      <div style={{ padding: '8px 12px 28px', background: cardBg, boxShadow: dark ? 'none' : '0 -1px 0 ' + line,
        display: 'flex', gap: 8, alignItems: 'center' }}>
        <div style={{ flex: 1, background: dark ? 'rgba(255,255,255,0.05)' : FX.paper,
          border: `1px solid ${line}`, borderRadius: 999, padding: '11px 16px',
          ...FxText, fontSize: 14, color: mute }}>Escreva sua dúvida…</div>
        <div style={{ width: 42, height: 42, borderRadius: 42, background: brand,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: `0 4px 12px rgba(59,95,226,0.3)` }}>
          <FxIcon name="send" size={16} color="#fff" stroke={1.8}/>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────
// NOTIFICAÇÕES — central de alertas
// ─────────────────────────────────────────────────────
function FxNotificacoes({ dark = false }) {
  const bg = dark ? FX.darkBg : FX.paper;
  const cardBg = dark ? FX.darkCard : FX.card;
  const ink = dark ? FX.darkInk : FX.ink;
  const mute = dark ? FX.darkInkMute : FX.inkMute;
  const line = dark ? FX.darkLine : FX.line;
  const brand = dark ? FX.brandAccent : FX.brand;

  const grupos = [
    { label:'Hoje', itens:[
      { tipo:'risco',    icon:'warn',     titulo:'Rafael Medeiros em risco alto',    sub:'9 dias sem treinar · aderência 45%',          time:'há 12min', lida:false },
      { tipo:'pag',      icon:'coin',     titulo:'Pagamento confirmado',              sub:'Beatriz Carvalho · R$ 380 · PIX',             time:'há 38min', lida:false },
      { tipo:'checkin',  icon:'check',    titulo:'Check-in: Beatriz Carvalho',       sub:'Superior Push A concluído · 52min',           time:'há 1h',    lida:false },
      { tipo:'ai',       icon:'spark',    titulo:'IA: progressão sugerida',          sub:'Beatriz · Supino +2.5kg disponível',          time:'há 2h',    lida:false },
    ]},
    { label:'Ontem', itens:[
      { tipo:'aluno',    icon:'users',    titulo:'Novo aluno cadastrado',             sub:'Gabriel Moura entrou via convite',           time:'25/04 18:30', lida:true },
      { tipo:'pag',      icon:'coin',     titulo:'Mensalidade atrasada',              sub:'Rafael Medeiros · R$ 450 · 9 dias de atraso', time:'25/04 08:00', lida:true },
      { tipo:'feed',     icon:'trend',    titulo:'Post fixado no feed',              sub:'"Dica: pausa entre séries" recebeu 14 curtidas', time:'25/04 09:15', lida:true },
    ]},
  ];

  const tipoColor = {
    risco:   dark ? '#FF8B8B' : FX.bad,
    pag:     dark ? '#6FE296' : FX.good,
    checkin: brand,
    ai:      dark ? '#9B7AFF' : '#6B46C1',
    aluno:   brand,
    feed:    dark ? '#E2B46F' : FX.warn,
  };

  return (
    <div style={{ background: bg, minHeight: '100%', paddingBottom: 110 }}>
      <div style={{ height: 54 }} />
      <div style={{ padding: '10px 20px 18px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div style={{ ...FxDisplay, fontSize: 28, fontWeight: 700, color: ink, letterSpacing: '-0.025em' }}>Notificações</div>
        <div style={{ ...FxText, fontSize: 13, fontWeight: 600, color: brand }}>Marcar lidas</div>
      </div>

      {grupos.map((g, gi) => (
        <div key={gi} style={{ marginBottom: 8 }}>
          <div style={{ padding: '4px 20px 10px', ...FxText, fontSize: 12, fontWeight: 700, color: mute,
            textTransform: 'uppercase', letterSpacing: '0.06em' }}>{g.label}</div>
          <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 6 }}>
            {g.itens.map((n, i) => {
              const c = tipoColor[n.tipo] || brand;
              return (
                <div key={i} style={{ background: cardBg, borderRadius: 18, padding: '14px 14px',
                  border: `1px solid ${n.lida ? line : c + '33'}`,
                  display: 'flex', alignItems: 'flex-start', gap: 12,
                  opacity: n.lida ? 0.75 : 1,
                }}>
                  <div style={{ width: 40, height: 40, borderRadius: 13, flexShrink: 0,
                    background: `${c}18`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    position: 'relative',
                  }}>
                    <FxIcon name={n.icon} size={18} color={c} stroke={1.8}/>
                    {!n.lida && (
                      <div style={{ position: 'absolute', top: 0, right: 0, width: 9, height: 9, borderRadius: 9,
                        background: c, border: `2px solid ${cardBg}` }}/>
                    )}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ ...FxText, fontSize: 14, fontWeight: n.lida ? 500 : 700, color: ink, letterSpacing: '-0.01em' }}>{n.titulo}</div>
                    <div style={{ ...FxText, fontSize: 12, color: mute, marginTop: 2, lineHeight: 1.35 }}>{n.sub}</div>
                  </div>
                  <div style={{ ...FxText, fontSize: 11, color: mute, flexShrink: 0, marginTop: 1 }}>{n.time}</div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

Object.assign(window, {
  FxBroadcasts, FxAvaliacaoFisica, FxPlanoAlimentar, FxPlanoSucesso, FxSuporte, FxNotificacoes,
});
